﻿#include <iostream>
#include <string>
#include <Windows.h>
#include <iomanip>
#include <vector>
#include <fstream>
#include "lodepng.h"
#include "mpi.h"

typedef unsigned char uchar;
typedef unsigned int uint;

using namespace std;
using namespace lodepng;
const int n = 11;
int n_2 = n / 2;

int** ExtensionMatrix()
{
    int** matr = new int* [n];
    for (int i = 0; i < n; i++)
        matr[i] = new int[n];

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            matr[i][j] = 0;

    for (int i = 0; i < n; i++)
    {
        matr[n / 2][i] = 1;
        matr[i][n / 2] = 1;
    }
    return matr;
}

int ToFilter(int x, int y, vector<uchar> image, uint Rwidth, uint Rheight, int** exMatr, int color_int)
{
    int color = 0;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            color += image[((y + n_2 - i) * Rheight + x + n_2 - j) * 3 + color_int] * exMatr[i][j];
    int div = 2 * n - 1;
    return color / div;
}

vector<uchar> IncreaseImage(string inputfilename, uint& Rwidth, uint& Rheight)
{
    vector<uchar> image;
    uint width, height;
    decode(image, width, height, inputfilename, LCT_RGB);

    Rwidth = width + n_2 * 2, Rheight = height + n_2 * 2;
    vector<uchar> res(Rwidth * Rheight * 3, 0);

    for (int i = 0; i < width; i++)
        for (int j = 0; j < n_2; j++)
        {
            // Заполняем левый дополнительный участок
            int left_r = ((i + n_2) * Rheight + j) * 3;
            int left_i = (i * height + 0) * 3;
            for (int k = 0; k < 3; k++)
                res[left_r + k] = image[left_i + k];
            // Заполняем верхний дополнительный участок
            int top_r = (j * Rheight + i + n_2) * 3;
            int top_i = (0 * height + i) * 3;
            for (int k = 0; k < 3; k++)
                res[top_r + k] = image[top_i + k];
            // Заполняем нижний дополнительный участок
            int bottom_r = ((Rwidth - 1 - j) * Rheight + i + n_2) * 3;
            int bottom_i = ((width - 1) * height + i) * 3;
            for (int k = 0; k < 3; k++)
                res[bottom_r + k] = image[bottom_i + k];
            // Заполняем правый дополнительный участок
            int right_r = ((i + n_2) * Rheight + Rwidth - 1 - j) * 3;
            int right_i = (i * height + height - 1) * 3;
            for (int k = 0; k < 3; k++)
                res[right_r + k] = image[right_i + k];
        }

    // Заполняем центр
    for (int i = 0; i < width; i++)
        for (int j = 0; j < width; j++)
        {
            int r = ((i + n_2) * Rheight + j + n_2) * 3;
            int im = (i * height + j) * 3;
            for (int k = 0; k < 3; k++)
                res[r + k] = image[im + k];
        }

    for (int i = 0; i < n_2; i++)
        for (int j = 0; j < n_2; j++)
        {
            // Заполняем верхний левый угол
            int top_left_r = (i * Rheight + j) * 3;
            int top_left_i = (0 * height + 0) * 3;
            for (int k = 0; k < 3; k++)
                res[top_left_r + k] = image[top_left_i + k];
            // Заполняем нижний левый угол
            int bottom_left_r = ((Rwidth - 1 - i) * Rheight + j) * 3;
            int bottom_left_i = ((height - 1) * height + 0) * 3;
            for (int k = 0; k < 3; k++)
                res[bottom_left_r + k] = image[bottom_left_i + k];
            // Заполняем верхний правый угол
            int top_right_r = (i * Rheight + Rwidth - 1 - j) * 3;
            int top_right_i = (0 * height + height - 1) * 3;
            for (int k = 0; k < 3; k++)
                res[top_right_r + k] = image[top_right_i + k];
            // Заполняем нижний правый угол
            int bottom_right_r = ((Rwidth - 1 - i) * Rheight + Rwidth - 1 - j) * 3;
            int bottom_right_i = ((width - 1) * height + height - 1) * 3;
            for (int k = 0; k < 3; k++)
                res[bottom_right_r + k] = image[bottom_right_i + k];
        }
    return res;
}


vector<uchar> FilterExtensionMatrix(int rank, vector<uchar> image, uint Rwidth, uint Rheight, int** exMatr)
{
    uchar* imageArr = nullptr;
    uchar* resArr = new uchar[(Rwidth - n_2 * 2) * (Rheight - n_2 * 2) * 3];
    MPI_Datatype MY_MPI_ROW, MY_MPI_ROW_R;
    MPI_Type_vector(1, (Rwidth - n_2 * 2) * 3, (Rheight - n_2 * 2) * 3, MPI_UNSIGNED_CHAR, &MY_MPI_ROW);
    MPI_Type_vector(1, Rwidth * 3, Rheight * 3, MPI_UNSIGNED_CHAR, &MY_MPI_ROW_R);
    MPI_Type_commit(&MY_MPI_ROW);
    MPI_Type_commit(&MY_MPI_ROW_R);

    if (rank == 0) {
        imageArr = new uchar[Rwidth * Rheight * 3];
        for (int i = 0; i < Rwidth * Rheight * 3; i++)
        {
            imageArr[i] = image[i];
        }
    }

    // Количество строчек для каждого процесса
    int countRow = (Rheight - n_2 * 2) / 4;
    int* sendcounts = new int[4];
    int* displs = new int[4];
    for (int i = 0; i < 4; i++)
    {
        sendcounts[i] = countRow + n_2 * 2;
        displs[i] = i * countRow;
    }

    uchar* partImage = new uchar[Rwidth * sendcounts[rank] * 3];

    
    MPI_Scatterv(&imageArr[0],
        sendcounts,
        displs,
        MY_MPI_ROW_R,
        &partImage[0],
        sendcounts[rank],
        MY_MPI_ROW_R,
        0,
        MPI_COMM_WORLD);
    

    uchar* partRes = new uchar[countRow * (Rwidth - n_2 * 2) * 3];
    
    for (int i = n_2; i < Rwidth - n_2; i++)
        for (int j = n_2; j < countRow + n_2; j++)
        {
            int ind = ((j - n_2) * (Rwidth - n_2 * 2) + (i - n_2)) * 3;
            //resArr[int ind = ((i - n_2) * (Rheight - n_2 * 2) + j - n_2) * 3;
            for (int k = 0; k < 3; k++) {
                int color = 0;
                for (int x = -n_2; x <= n_2; x++) {
                    for (int y = -n_2; y <= n_2; y++) {
                        int nInd = (Rwidth * (j + y) + (i + x)) * 3 + k;
                        color += exMatr[x + n_2][y + n_2] * partImage[nInd];
                    }
                }
                partRes[ind + k] = color / (2 * n - 1);
            }
        }
    
    for (int i = 0; i < 4; i++)
    {
        sendcounts[i] = countRow;
        displs[i] = i * countRow;
    }

    MPI_Gatherv(&partRes[0],
        sendcounts[rank],
        MY_MPI_ROW,
        &resArr[0],
        sendcounts,
        displs,
        MY_MPI_ROW,
        0,
        MPI_COMM_WORLD);

    vector<uchar> res(&resArr[0], &resArr[0] + (Rwidth - n_2 * 2) * (Rheight - n_2 * 2) * 3);

    MPI_Type_free(&MY_MPI_ROW);
    MPI_Type_free(&MY_MPI_ROW_R);
    delete[] imageArr;
    delete[] resArr;
    delete[] partImage;
    delete[] partRes;
    delete[] sendcounts;
    delete[] displs;

    return res;
}

int main(int argc, char** argv)
{
    int size, rank;
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    int** exMatr = ExtensionMatrix();
    vector<double> time_;
   
    for (int i = 4; i <= 2048; i *= 2)
    {
        double times = 0;

        for (int count = 0; count < 1000; count++)
        {
            // Замена на uchar*

            vector<uchar> increasedImage;
            uint Rwidth, Rheight;

            if (rank == 0)
            {
                string input = "C:\\tmp\\Images\\" + std::to_string(i) + 'x' + std::to_string(i) + ".png";
                increasedImage = IncreaseImage(input, Rwidth, Rheight);
            }

            MPI_Bcast(&Rwidth, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
            MPI_Bcast(&Rheight, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
            // Замена на uchar*
            double tStart = MPI_Wtime();
            vector<uchar> result = FilterExtensionMatrix(rank, increasedImage, Rwidth, Rheight, exMatr);
            double time = MPI_Wtime() - tStart;

            double maxTime;
            MPI_Reduce(&time, &maxTime, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

            if (rank == 0)
            {
                /*cout << "MPI algorithm finished. Image: " << to_string(i) << "x" << to_string(i) << " Time: " << setprecision(6) << maxTime << endl;*/
                /*time_.push_back(maxTime);*/
                times += maxTime;
                string output = std::to_string(i) + 'x' + std::to_string(i) + "_new.png";
                /*encode(output, result, Rwidth - 2 * n_2, Rheight - 2 * n_2, LCT_RGB);*/
            }
        }
        if (rank == 0)
            time_.push_back(times / 1000);
    }
    

    if (rank == 0)
    {
        ofstream fTime("time.txt");
        for (int i = 0; i < time_.size(); i++)
            fTime << "Image: " << to_string(pow(2, i + 2)) << "x" << to_string(pow(2, i)) << " Time: " << setprecision(6) << time_[i] << endl;
        fTime.close();
    }
    for (int i = 0; i < n; i++)
        delete[] exMatr[i];
    delete[] exMatr;
    MPI_Finalize();
}